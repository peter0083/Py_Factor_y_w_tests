===========
Py Factor-y
===========

'Py Factor-y' provides a way to calculate standard deviation. Typical usage
often looks like this::

    #!/usr/bin/env python

    import standard_deviation from Py_Factor_y

    standard_deviation(x)


Info
=========

To install this repo, type this from an instance of git bash:

pip install git+ssh://github.ubc.ca/cmorano/Py_Factor_y.git

The original repository can be found at https://github.ubc.ca/cmorano/Py_Factor_y.
