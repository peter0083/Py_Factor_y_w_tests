from .my_py_sd import standard_deviation
